## Tutorial 06
**Name**: Vidun Jayakody
**Student ID**: 101224988
**Link**: https://youtu.be/HAg8VoXJNBI
**Install Instructions**: `cd` into the `/demo_code/` directory containing the `package.json` file and install dependencies.
**Command to Install Dependencies**:
```
npm install
```
**Start server command and location**: in `/demo_code/02ExpressServer`, run `node 02_express_static_server.js` and visit the url at http://localhost:3000/index.html. Notice the console output as you go through the different